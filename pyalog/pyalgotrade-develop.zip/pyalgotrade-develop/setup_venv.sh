#!/bin/sh

virtualenv venv
source venv/bin/activate
pip --no-cache-dir install -r requirements-dev.txt


