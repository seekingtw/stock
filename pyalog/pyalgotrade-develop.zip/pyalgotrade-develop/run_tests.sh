#!/bin/sh

nosetests testcases
