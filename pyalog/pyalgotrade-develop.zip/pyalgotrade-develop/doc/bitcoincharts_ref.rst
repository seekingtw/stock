bitcoincharts -- Bitcoin Charts reference
=========================================

Feeds
-----

.. automodule:: pyalgotrade.bitcoincharts.barfeed
    :members:
    :show-inheritance:
