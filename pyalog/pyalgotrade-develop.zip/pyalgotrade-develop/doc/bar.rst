bar -- Instrument prices
========================

.. automodule:: pyalgotrade.bar
    :members:
    :member-order: bysource
    :special-members:
    :exclude-members: __weakref__
    :show-inheritance:
