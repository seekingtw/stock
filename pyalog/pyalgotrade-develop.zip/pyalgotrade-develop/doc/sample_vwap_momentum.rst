VWAP Momentum Trade
===================

This example is based on `Momentum Trade <https://www.quantopian.com/posts/momentum-trade>`_

.. literalinclude:: ../samples/vwap_momentum.py

this is what the output should look like:

.. literalinclude:: ../samples/vwap_momentum.output

and this is what the plot should look like:

.. image:: ../samples/vwap_momentum.png

You can get better returns by tunning the VWAP and threshold parameters.

